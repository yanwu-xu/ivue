const model = [
    {
        name: `Amy的城堡纸盒`,
        image: `https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=94996843,1878572032&fm=26&gp=0.jpg`,
        body: '全新, 隐蔽性好',
    },
    {
        name: 'Baddy的饼干盒',
        image: `https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=1125791419,1561105245&fm=26&gp=0.jpg`,
        body: '适合瘦身塑行',
    },
    {
        name: 'Corney的飞行纸盒',
        image: `https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1592014377244&di=da390556e384c148a63692fee68b6251&imgtype=0&src=http%3A%2F%2Fpic4.zhimg.com%2Fv2-0d4d16b3aa0e23d656bc1a94d7dc7ea7_b.jpg`,
        body: '时尚折边',
    },
    {
        name: 'Lanzi的敞篷纸盒',
        image: `https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=1208176849,1584967837&fm=26&gp=0.jpg`,
        body: '超大空间，买就送鱼罐头',
    }
];

export default model;
