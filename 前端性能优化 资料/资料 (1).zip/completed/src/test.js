export default () => {
    const add = ((a, b) => a*b);
    const num1 = 1;
    const num2 = 2;
    add(num1, num2);
}